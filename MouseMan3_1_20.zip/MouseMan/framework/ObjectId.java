package framework;

public enum ObjectId{
    Player(),
    Player2(),
    Block(),
    BackgroundBlock(),
    Bullet(),
    Flag();
}