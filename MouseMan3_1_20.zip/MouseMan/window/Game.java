package window;

import java.awt.*;
import java.awt.image.*;
import java.awt.image.BufferStrategy;

import framework.*;
import objects.*;

// import javax.swing.*;

/**
 * Game
 */
public class Game extends Canvas implements Runnable {

    private static final long serialVersionUID = 1L;

    private boolean running = false;
    private Thread thread;
    private BufferedImage level = null, bgStuff;

    // objects
    Handler handler;
    Camera cam;
    static Texture tex; // ToDo : static or not?

    public static int WIDTH, HEIGHT;
    public static float CamX, CamY;
    //private long startTime = System.currentTimeMillis();

    private void init() {
        WIDTH = getWidth();
        HEIGHT = getHeight();

        tex = new Texture();

        BufferedImageLoader loader = new BufferedImageLoader();
        level = loader.loadImage("/Users/hasenmafia/Desktop/Games/MouseMan/res/map.png"); // should load image
        // level = loader.loadImage("/map.png"); // should load image lol
        bgStuff = loader.loadImage("/Users/hasenmafia/Desktop/Games/MouseMan/res/Bambstraw10.png");
        handler = new Handler();

        cam = new Camera(0, 0);

        loadImageLevel(level);

        // handler.addObject(new Player(100,100,handler, ObjectId.Player) );
        // handler.createLevel();

        this.addKeyListener(new KeyInput(handler));
    }

    private void loadImageLevel(BufferedImage image) {
        int w = image.getWidth();
        int h = image.getHeight();
        int px=352, py=352;
        int counter = 0;

        System.out.println("width: " + w + " height: " + h);

        for (int xx = 0; xx < w; xx++) {
            for (int yy = 0; yy < h; yy++) {
                int pixel = image.getRGB(xx, yy);
                int red = (pixel >> 16) & 0xff;
                int green = (pixel >> 8) & 0xff;
                int blue = (pixel) & 0xff;

                if (red == 255 && green == 255 && blue == 255) {    // block
                    handler.addObject(new Block(xx * 32, yy * 32, 0, ObjectId.Block));
                    counter++;
                }
                if (red == 191 && green == 191 && blue == 191) {    // block top
                    handler.addObject(new Block(xx * 32, yy * 32, 1, ObjectId.Block));
                    counter++;
                }
                if (red == 165 && green == 165 && blue == 165) {    // block cracked
                    handler.addObject(new Block(xx * 32, yy * 32, 2, ObjectId.Block));
                    counter++;
                }
                if (red == 126 && green == 121 && blue == 116) {    // crate
                    handler.addObject(new Block(xx * 32, yy * 32, 3, ObjectId.Block));
                    counter++;
                }
                if (red == 255 && green == 217 && blue == 0) {    // Flag (or similar dunno)
                    handler.addObject(new Flag(xx * 32, yy * 32, ObjectId.Flag));
                    counter++;
                }
                if (red == 85 && green == 85 && blue == 85) handler.addObject(new BackgroundBlock(xx*32, yy*32, 4, ObjectId.BackgroundBlock));
                if (red == 0 && green == 0 && blue == 255) {
                    //handler.addObject(new Player(xx * 32, yy * 32, handler, ObjectId.Player));
                    px = xx*32;
                    py = yy*32;
                }
            }
        }
        handler.addEntity(new Player2(px, py, handler, ObjectId.Player2));
        System.out.println(counter);
    }

    public synchronized void start() {
        if (running) {
            return;
        }
        running = true;
        thread = new Thread(this);
        thread.start();
    }

    public void run() {
        init();
        this.requestFocus();
        long lastTime = System.nanoTime();
        double amountOfTicks = 60.0;
        double ns = 1000000000 / amountOfTicks;
        double delta = 0;
        long timer = System.currentTimeMillis();
        int updates = 0;
        int frames = 0;
        while (running) {
            long now = System.nanoTime();
            delta += (now - lastTime) / ns;
            lastTime = now;
            while (delta >= 1) {
                tick();
                updates++;
                delta--;
                // System.out.println("delta "+delta+" ti "+updates);
            }
            render();
            frames++;

            if (System.currentTimeMillis() - timer > 1000) {
                timer += 1000;
                // fps = frames;
                // ticks = updates;
                System.out.println("FPS: " + frames + ", ticks: " + updates);
                frames = 0;
                updates = 0;
            }
        }
    }

    private void tick() {
        handler.tick();
        for (int i = 0; i < handler.entity.size(); i++) {
            if (handler.entity.get(i).getId() == ObjectId.Player2) {
                cam.tick(handler.entity.get(i));
            }
        }
    }

    private void render() {
        BufferStrategy bs = this.getBufferStrategy();
        if (bs == null) {
            this.createBufferStrategy(3);
            return;
        }
        Graphics g = bs.getDrawGraphics();
        Graphics2D g2d = (Graphics2D) g;
        //////////////////////////////////////////

        g.setColor(new Color(135, 131, 127));
        g.fillRect(0, 0, getWidth(), getHeight());

        // g.drawImage(bgStuff, 0, 100, 100, 100, null, null);

        g2d.translate(cam.getX(), cam.getY()); // start of cam
        CamX = cam.getX();
        CamY = cam.getY();

        for (int xx = 0; xx < bgStuff.getWidth()*3/10; xx+=bgStuff.getWidth()/10) {
            g.drawImage(bgStuff, xx, 200, 100, 100, null);
        }
        handler.render(g);

        g2d.translate(-cam.getX(), -cam.getY()); // end of cam

        //////////////////////////////////////////

        g.dispose();
        bs.show();
    }

    public static Texture getInstance() {
        return tex;
    }

    public static void main(String[] args) {
        new Window(800, 600, "title", new Game());
    }
}