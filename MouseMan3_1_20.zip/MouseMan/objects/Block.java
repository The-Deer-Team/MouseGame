package objects;

// import java.awt.Color;
import java.awt.Graphics;
import java.awt.Rectangle;
import java.util.LinkedList;

import framework.*;
import window.*;
// import window.*;

/**
 * Block
 */
public class Block extends Obstacle {

    Texture tex = Game.getInstance();
    private int type;

    public Block(float x, float y, int type, ObjectId id) {
        super(x, y, id);
        this.type = type;
    }

    public void tick(LinkedList<GameObject> object) {
    }

    public void render(Graphics g) {
        // if (type == 0){ // wall
        //     g.drawImage(tex.block[0], (int)x, (int)y, null);
        // }
        // if (type == 1){ // grass
        //     g.drawImage(tex.block[1], (int)x, (int)y, null);
        // }
        // g.setColor(Color.green);
        // g.drawRect((int)x, (int)y, 32, 32);
        if (y+Game.CamY>-32 && y+Game.CamY<Game.HEIGHT && 
            x+Game.CamX>-32 && x+Game.CamX<Game.WIDTH
            ){
            g.drawImage(tex.block[type], (int)x, (int)y, null);
        }
    }

    public Rectangle getBounds() {
        return new Rectangle((int)x, (int)y, 32, 32);
    }

}