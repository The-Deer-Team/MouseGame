package framework;

import java.awt.*;
import java.util.LinkedList;
/**
 * Entity
 */
public abstract class Entity extends GameObject {

    public Entity(float x, float y, ObjectId id) {
        super(x, y, id);
    }

    protected int width, height;
    protected boolean falling = true;
    protected float speedX = 0, speedY = 0;
    protected double maxSpeedX, maxSpeedY;
    protected float x_old, y_old;
    protected int facing = 1;
    // 1 = right,
    // -1 = left
    
    protected boolean jumping = false;
    protected boolean alive = true;
    protected float health;
    final static double gravity_strength = 1.5;

    public void move() { // called to move the Entity
        if (Math.abs(speedX) > maxSpeedX) {
            speedX = (float) ((speedX / Math.abs(speedX)) * maxSpeedX);

        }
        if (speedY > maxSpeedY) {
            speedY = (float) ((speedY / Math.abs(speedY)) * maxSpeedY);
        }
        x += speedX;
        y += speedY;
    }

    public void bounceX(int direction, float referenceFrame, int wwww) { // called on collision in X direction
        speedX *= -0.1;
        if (direction == 1) {
            x = referenceFrame - width - 1;
        } else if (direction == -1) {
            x = referenceFrame + wwww + 1;
        }
    }

    public void bounceY(int direction, double referenceFrame, int hhhh) { // called on collision in Y direction
        speedY *= -1;
        if (direction == 1) {
            y = (float) (referenceFrame - height - 1);
        } else if (direction == -1) {
            y = (float) (referenceFrame + hhhh + 1);
        }
        if (speedY < 2.5) {
            speedY = 0;
        }
    }

    protected void collision(LinkedList<GameObject> object) {
        for (int i = 0; i < object.size(); i++) {
            GameObject tempObject = object.get(i);
            if (tempObject.getId() == ObjectId.Block){
                if (getBoundsTop().intersects(tempObject.getBounds())) { // top
                    System.out.println("top");
                    y = tempObject.getY() + 32;
                    speedY = 0;
                }

                if (getBounds().intersects(tempObject.getBounds())) {
                    System.out.println("bottom");
                    y = tempObject.getY() - height;
                    speedY = 0;
                    falling = false;
                    jumping = false;
                } else {
                    falling = true;
                }

                // Right
                if (getBoundsRight().intersects(tempObject.getBounds())) {
                    System.out.println("right");
                    x = tempObject.getX() - width;
                }
                // Left
                if (getBoundsLeft().intersects(tempObject.getBounds())) {
                    System.out.println("left");
                    x = tempObject.getX() + 32;
                }
            }
        }
    }

    protected abstract Rectangle getBoundsTop();

    protected abstract Rectangle getBoundsRight();

    protected abstract Rectangle getBoundsLeft();

    abstract public void render(Graphics g);

    public void adjustPosition() {
        x_old = x;
        y_old = y;
    }

    public void gravity() {
        if (jumping || falling) {
            speedY += gravity_strength;
        }
    }

    public void friction() {
        if (speedX != 0) {
            speedX -= (speedX / Math.abs(speedX)) * function(speedX);
            // speedX = (speedX/Math.abs(speedX))/2;
        }
        if (Math.abs(speedX) < .5) {
            speedX = 0;
        }
        // System.out.println(speedX);
    }

    private double function(double x) {
        double f = -Math.abs(x) / 2;
        double h = Math.pow(Math.E, f) + 1;
        // System.out.println("friction "+h+" Speeed "+speedX);
        return h;
    }

    public void checkHealth() {
        if (health < 0.1) {
            alive = false;
        }
    }

    public boolean isFalling() {
        return falling;
    }

    public void setFalling(boolean falling) {
        this.falling = falling;
    }

    public boolean isJumping() {
        return jumping;
    }

    public void setJumping(boolean jumping) {
        this.jumping = jumping;
    }

    public float getSpeedX() {
        return speedX;
    }

    public float getSpeedY() {
        return speedY;
    }

    public void setSpeedX(float speedX) {
        this.speedX = speedX;
    }

    public void setSpeedY(float speedY) {
        this.speedY = speedY;
    }

    public float getOldX() {
        return x_old;
    }

    public float getOldY() {
        return y_old;
    }

    public void setOldX(float newX) {
        x_old = newX;
    }

    public void setOldY(float newY) {
        y_old = newY;
    }

    public int getFacing() {
        return facing;
    }

    public int getWidth() {
        return width;
    }
    public int getHeight() {
        return height;
    }

}