package objects;

import java.awt.Graphics;
import java.awt.Rectangle;
import java.util.LinkedList;

import framework.*;
import window.*;

/**
 * BackgroundBlock
 */
public class BackgroundBlock extends Obstacle {

    Texture tex = Game.getInstance();
    private int type;

    public BackgroundBlock(float x, float y, int type, ObjectId id) {
        super(x, y, id);
        this.type = type;
    }

    public void tick(LinkedList<GameObject> object) {
    }

    public void render(Graphics g) {
        if (y+Game.CamY>-32 && y+Game.CamY<Game.HEIGHT && 
            x+Game.CamX>-32 && x+Game.CamX<Game.WIDTH
            ){
            g.drawImage(tex.block[type], (int)x, (int)y, null);
        }
    }

    public Rectangle getBounds() {
        return new Rectangle((int)x, (int)y, 32, 32);
    }

}
