package window;

import java.util.LinkedList;
import java.awt.*;

import framework.*;
// import objects.*;


/**
 * Handler
 */
public class Handler {

    public LinkedList<GameObject> object = new LinkedList<GameObject>();
    public LinkedList<GameObject> entity = new LinkedList<GameObject>();

    private GameObject tempObject;

    public void tick() {
        for (int i = 0; i < object.size(); i++) {
            tempObject = object.get(i);

            tempObject.tick(object);
        }
        for (int i = 0; i < entity.size(); i++) {
            tempObject = entity.get(i);

            tempObject.tick(object);
        }
    }
    
    public void render(Graphics g) {
        for (int i = 0; i < object.size(); i++) {
            tempObject = object.get(i);
            if (tempObject.getY()+Game.CamY>-32 && tempObject.getY()+Game.CamY<Game.HEIGHT && 
                tempObject.getX()+Game.CamX>-32 && tempObject.getX()+Game.CamX<Game.WIDTH
                ){
                tempObject.render(g);
            }
        }

        for (int i = 0; i < entity.size(); i++) {
            tempObject = entity.get(i);
            tempObject.render(g);
        }
    }

    public void addObject(GameObject object) {
        this.object.add(object);
    }
    
    public void removeObject(GameObject object) {
        this.object.remove(object);
    }

    public void addEntity(GameObject entity) {
        this.entity.add(entity);
    }
    
    public void removeEntity(GameObject entity) {
        this.entity.remove(entity);
    }

   
}