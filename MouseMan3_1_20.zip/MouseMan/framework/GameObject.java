package framework;

import java.util.*;
// import javax.swing.*;
import java.awt.*;

/**
 * GameObject
 */
public abstract class GameObject {

    protected float x, y;
    protected ObjectId id;
    protected int width, height;

    public GameObject(float x, float y, ObjectId id) {
        this.x = x;
        this.y = y;
        this.id = id;
    }

    public abstract void tick(LinkedList<GameObject> object);

    public abstract void render(Graphics g);

    public abstract Rectangle getBounds();

    public float getX() {
        return x;
    }

    public float getY() {
        return y;
    }

    public void setX(float x) {
        this.x = x;
    }

    public void setY(float y) {
        this.y = y;
    }

    public ObjectId getId() {
        return id;
    }

    // method for obstacle
    abstract public int newCollideX(Entity e);
    abstract public int newCollideY(Entity e);

    
    // getters and setters for Entities
    abstract public boolean isFalling();
    abstract public void setFalling(boolean falling);
    abstract public boolean isJumping();
    abstract public void setJumping(boolean jumping);
    abstract public float getSpeedX();
    abstract public float getSpeedY();
    abstract public void setSpeedX(float speedX);
    abstract public void setSpeedY(float speedY);
    abstract public float getOldX();
    abstract public float getOldY();
    abstract public void setOldX(float newX);
    abstract public void setOldY(float newY);
    abstract public int getFacing();
    abstract public int getWidth();
    abstract public int getHeight();

}