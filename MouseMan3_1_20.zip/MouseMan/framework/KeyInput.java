package framework;

import java.awt.event.*;
import window.*;
import objects.Bullet;

/**
 * KeyInput
 */
public class KeyInput extends KeyAdapter{

    Handler handler;

    public KeyInput(Handler handler) {
        this.handler = handler;
    }

    public void keyPressed(KeyEvent e) {
        int key = e.getKeyCode();

        for (int i = 0; i < handler.entity.size(); i++) {
            GameObject tempEntity = handler.entity.get(i);
            if (tempEntity.getId() == ObjectId.Player2){
                if (key == KeyEvent.VK_D) tempEntity.setSpeedX(5);
                if (key == KeyEvent.VK_A) tempEntity.setSpeedX(-5);
                if ((key == KeyEvent.VK_W||key == KeyEvent.VK_SPACE) && 
                        !tempEntity.isJumping()){
                    tempEntity.setSpeedY(-25);
                    tempEntity.setJumping(true);
                }else{
                    tempEntity.setFalling(true);
                }
                if (key == KeyEvent.VK_E){
                    handler.addEntity(new Bullet(tempEntity.getX(), tempEntity.getY(), ObjectId.Bullet, tempEntity.getFacing()*10, handler));
                }
            }
        }
        if (key == KeyEvent.VK_ESCAPE) {
            System.exit(1);
        }
    }

    public void keyReleased(KeyEvent e) {
        int key = e.getKeyCode();

        for (int i = 0; i < handler.entity.size(); i++) {
            GameObject tempEntity = handler.entity.get(i);
            if (tempEntity.getId() == ObjectId.Player2){
                if (key == KeyEvent.VK_D) tempEntity.setSpeedX(0);
                if (key == KeyEvent.VK_A) tempEntity.setSpeedX(0);
                if ((key == KeyEvent.VK_W||key == KeyEvent.VK_SPACE) && !tempEntity.isJumping()){
                    //tempEntity.setSpeedY(-25);
                    tempEntity.setJumping(true);
                }else{
                    tempEntity.setFalling(true);
                }
            }
        }
    }
}