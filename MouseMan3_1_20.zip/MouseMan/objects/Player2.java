package objects;

import java.awt.*;
import java.util.LinkedList;

import framework.*;
//import framework.GameObject;
//import framework.ObjectId;

import window.*;

/**
 * Player2
 */
public class Player2 extends Entity {


    private float width = 32, height = 64;

    Texture tex = Game.getInstance();
    private Animation playerWalk, playerWalkLeft;
    
    public Player2(float x, float y, Handler handler, ObjectId id) {
        super(x, y, id);
        maxSpeedX = 5;
        maxSpeedY = 32;
        playerWalkLeft  = new Animation(10, tex.player[3], tex.player[4], tex.player[5]);
        playerWalk  = new Animation(10, tex.player[0], tex.player[1], tex.player[2]);
    }

    public void tick(LinkedList<GameObject> object) {
        move();
        if (speedX < 0){
            facing = -1;
        }else if (speedX > 0) {
            facing = 1;
        }
        // System.out.println(speedX+" "+speedY);
        gravity();
        collision(object);
        playerWalk.runAnimation();
        playerWalkLeft.runAnimation();
    }

    protected void collision(LinkedList<GameObject> object) {
        for (int i = 0; i < object.size(); i++) {
            GameObject tempObject = object.get(i);
            if (tempObject.getId() == ObjectId.Block){
                if (getBoundsTop().intersects(tempObject.getBounds())) { // top
                    System.out.println("top");
                    y = tempObject.getY() + 32;
                    speedY = 0;
                }

                if (getBounds().intersects(tempObject.getBounds())) {
                    System.out.println("bottom");
                    y = tempObject.getY() - height;
                    speedY = 0;
                    falling = false;
                    jumping = false;
                } else {
                    falling = true;
                }

                // Right
                if (getBoundsRight().intersects(tempObject.getBounds())) {
                    System.out.println("right");
                    x = tempObject.getX() - width;
                }
                // Left
                if (getBoundsLeft().intersects(tempObject.getBounds())) {
                    System.out.println("left");
                    x = tempObject.getX() + 32;
                }
            }
        }
    }

    public void render(Graphics g) {
        if (speedX != 0) {
            // System.out.println(facing+" "+speedX);
             if (facing == 1){
                 //g.drawRect((int)x, (int)y, (int)width, (int)height);
                 playerWalk.drawAnimation(g, (int) x-32, (int) y+5, 95, (int)height);
             }
             else{
                 playerWalkLeft.drawAnimation(g, (int) x-32, (int) y+5, 95, (int)height);
             }
         } else {
             if (facing==1){
                 g.drawImage(tex.player[0], (int) x-32, (int) y+5,  95, (int)height, null);
             }else{
                 g.drawImage(tex.player[4], (int) x-32, (int) y+5,  95, (int)height, null);
             }
         }
    }

    public Rectangle getBounds() {
        return new Rectangle((int) ((int) x + (width / 2) - ((width / 2) / 2)), (int) y + (int) (height / 2),
                (int) width / 2, (int) height / 2);
    }
    public Rectangle getBoundsTop() {
        return new Rectangle((int) ((int) x + (width / 2) - (width / 2) / 2), (int) y, (int) width / 2,
                (int) height / 2);
    }
    public Rectangle getBoundsRight() {
        return new Rectangle((int) (x + width - 5), (int) y + 5, 5, (int) height - 10);
    }
    public Rectangle getBoundsLeft() {
        return new Rectangle((int) x, (int) y + 5, 5, (int) height - 10);
    }

    public int newCollideX(Entity e) {
        return 0;
    }

    public int newCollideY(Entity e) {
        return 0;
    }

}