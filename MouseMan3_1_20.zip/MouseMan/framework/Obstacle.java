package framework;

import java.awt.Graphics;
import java.awt.Rectangle;
import java.util.LinkedList;


import framework.*;
// import engines.*;
/**
 * Obstacle
 */
public abstract class Obstacle extends GameObject {

    public Obstacle(float x, float y, ObjectId id) {
        super(x, y, id);
    }

    public boolean collideX(Entity e) {
        if (isApproxEqual(e.x - x, e.width) || isApproxEqual(e.x - x, width)) {
            return true;
        }
        return false;
    }

    public boolean collideY(Entity e) {
        if (isApproxEqual(e.y - y, -e.height) || isApproxEqual(e.y - y, height)) {
            return true;
        }
        return false;
    }

    private boolean isApproxEqual(double a, double b) {
        double err = 0.05 * a;
        if (a + err > b && a - err < b) {
            return true;
        }
        return false;
    }

    public int newCollideX(Entity e) {
        if (e.y <= y + height && e.y + e.height >= y) {
            if ((x + width <= e.x_old && x + width >= e.x) || (x <= e.x_old + e.width && x >= e.x + e.width)) {
                return -1;
            }
            if ((x + width >= e.x_old && x + width <= e.x) || (x >= e.x_old + e.width && x <= e.x + e.width)) {
                return 1;
            }
        }
        return 0;
    }

    public int newCollideY(Entity e) {
        // e.standing = false;

        if (e.x <= x + width && e.x + e.width >= x) {
            if ((y + height <= e.y_old && y + height >= e.y) || (y <= e.y_old + e.height && y >= e.y + e.height)) {
                return -1;
            }
            if ((y + height >= e.y_old && y + height <= e.y) || (y >= e.y_old + e.height && y <= e.y + e.height)) {
                e.falling = false;
                e.jumping = false;
                return 1;
            }
        }
        return 0;
    }

    public void tick(LinkedList<GameObject> object) {

    }

    abstract public void render(Graphics g);

    abstract public Rectangle getBounds();

    public int getWidth() {
        return width;
    }
    public int getHeight() {
        return height;
    }

    

    // dead getters and setters
    public boolean isFalling() {
        return false;
    }
    public void setFalling(boolean falling) {
    }
    public boolean isJumping() {
        return false;
    }
    public void setJumping(boolean jumping) {}
    public float getSpeedX() {
        return 0;
    }
    public float getSpeedY() {
        return 0;
    }
    public void setSpeedX(float speedX) {}
    public void setSpeedY(float speedY) {}
    public float getOldX() {
        return 0;
    }
    public float getOldY() {
        return 0;
    }
    public void setOldX(float newX) {}
    public void setOldY(float newY) {}
    public int getFacing() {
        return 0;
    }

}
