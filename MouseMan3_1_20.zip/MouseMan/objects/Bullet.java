package objects;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Rectangle;
import java.util.LinkedList;

import framework.*;
import window.*;

/**
 * Bullet
 */
public class Bullet extends Entity {

    Handler handler;

    private float x0;

    public Bullet(float x, float y, ObjectId id, int speedX, Handler handler) {
        super(x, y, id);
        this.speedX = speedX;
        this.handler = handler;
        x0 = x;
    }

    public void tick(LinkedList<GameObject> object) {
        x += speedX;
        if (Math.abs(x - x0) > 1000) {
            despawn();
        }
    }

    public void render(Graphics g) {
        g.setColor(Color.ORANGE);
        g.fillRect((int) x, (int) y, 10, 10);
    }

    public Rectangle getBounds() {
        return new Rectangle((int) x, (int) y, 16, 16);
    }

    private void despawn() {
        handler.removeObject(this);
    }

    public int newCollideX(Entity e) {
        return 0;
    }

    public int newCollideY(Entity e) {
        return 0;
    }

    protected Rectangle getBoundsTop() {
        return null;
    }

    protected Rectangle getBoundsRight() {
        return null;
    }

    protected Rectangle getBoundsLeft() {
        return null;
    }

}