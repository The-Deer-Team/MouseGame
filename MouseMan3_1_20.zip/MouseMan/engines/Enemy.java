package engines;

import java.awt.Graphics;
import java.awt.Rectangle;
import java.util.LinkedList;

import framework.*;


/**
 * Enemy
 */
public abstract class Enemy extends Entity {

    private float dist;
    private long waiting;


    public Enemy(float x, float y,  ObjectId id) {
        super(x, y, id);
	}

    abstract public void render(Graphics g);

    public void tick(LinkedList<GameObject> object){
        for (int i = 0; i < object.size(); i++) {
            if (object.get(i).getId() == ObjectId.Player2){
                dist = object.get(i).getX()+object.get(i).getHeight()/2 - x;
            }
        }
    }

    abstract protected void pathfinding(Entity player);

    abstract public Rectangle getBounds();

    
}

/**
 * class Enemy extends Entity {

  float dist;

  long startWaiting=0;  //new
  boolean currentlyAttacking=false;//new

  Enemy (float a, float b, float c, float d, float e, float f, float g, int h) {
    x = a;
    y = b;
    Width = c;
    Height = d;
    maxSpeedX = e;
    maxSpeedY = f;
    health = g;
    dmg = h;
    alive = true;
    attackCount = 0;
  }

  void update() {       //tick
    text(x+", "+dist, (float)x, 200);
    alive = true;

    dist = Player.posX+Player.Height/2 - posX;

    distAttack = sqrt(pow(dist, 2)+pow(Player.posY-Player.Height/2 - posY, 2));

    Enemove();

    text(health, posX-10, posY-15);
    fill(0, 255, 0, 100);
    ellipse(posX, posY, Width, Height );
  }

  public void Enemove() {

    if ((abs(dist) > 50) && (abs(dist) < 600)) {
      speedX = maxSpeedX * (dist/abs(dist));
    }

    if ((dist > -50) && (dist < 50) && (speedX != 0)) { // pls adjust
      speedX -= (speedX/abs((float)speedX))/2;
    }

    move();
    adjustPosition();

    if ((abs(dist) < 50 && Player.alive)) {
      attack();
      if (!currentlyAttacking) {
        startWaiting = millis();
        currentlyAttacking = true;
      }
    }
  }

  public void attack() {

    attackDelay = 1000;
    timer();

    if (attack) {
      x -= 30 * (dist/abs(dist));
      //lunge();
      //if (millis()>startWaiting+attackDelay) {
       // currentlyAttacking = false;
        if (distAttack < 50 && attackCount < 2) { //pls adjust
          Player.health -= dmg;
          attackCount++;
       // }
      }
    }

    if (health <= 0) {
      alive = false;
    }
  }
}

 */